public class Objeto {
    
}
