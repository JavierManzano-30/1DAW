public class Camiseta {
    
}
