public class Comestible {
    
}
