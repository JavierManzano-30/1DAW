public class Pantalon {
    
}
